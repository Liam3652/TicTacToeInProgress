// The AI won't play it's turn

import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './AppAI';

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);