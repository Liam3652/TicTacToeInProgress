from flask import Flask, jsonify, request
import random

app = Flask(__name__)

@app.route('/ai-move', methods=['POST'])
def ai_move():
    board = request.json.get('board')
    empty_boxes = [i for i, value in enumerate(board) if value is None]
    ai_move = random.choice(empty_boxes) if empty_boxes else None

    return jsonify({'aiMove': ai_move})

if __name__ == '__main__':
    app.run(debug=True)